num=input("Enter your number: ")
order=len(str(num))
sum=0
temp=num
while temp > 0:
    digit=temp%10
    sum+=digit**order
    temp //=10

if sum==num:
    print('{0} Is Armstrong Number'.format(num))
else:
    print('{0} Is not Armstrong Number'.format( num ))

