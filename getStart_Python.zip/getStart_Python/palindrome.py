def revers(s):
    return s[::-1]


def isPalindrome(s):
    rev = revers( s )

    if (s == rev):
        return True
    return False


s = input( "Enter your input" )
ans = isPalindrome( s )

if ans == 1:
    print( "It is palindrome" )
else:
    print( "It is not palindrome" )
