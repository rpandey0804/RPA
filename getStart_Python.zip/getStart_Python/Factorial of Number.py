
def fact_Recursion(n):
    if n==1:
        return n
    else:
        return n * fact_Recursion(n-1)

num=input("Enter yor no :")

if num <0:
    print(num,"Number is Negative")
elif num==0:
    print(num,"Number is 0")
else:
    print("The factorial of", num, "is", fact_Recursion( num ))
