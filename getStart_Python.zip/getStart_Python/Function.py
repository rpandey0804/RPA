import random
print ("A random number from list is : ")
print (random.choice([1, 4, 8, 10, 3]))