#String
'''str1='Rohit'
str2='Pandey'
#Concatenation
print(str1 + str2)
#Repetation
print(str1*2)
#Slicing
print(str1[2:3])
print(str1[:10])
print(str1[2:])

#Indexing
print("Hello")
print(str1[-1] +str1[0])
#find,Replace,split,count
print(str1.find("Rohit"))
print(str1.replace('R','M'))
print(str1)
'''
# TUPLES
'''myTuple=('Rohit',2.4,5,'Pandey')
print(type(myTuple))
myTuple1=('Capgemini','India')
print(myTuple +(myTuple1))
'''
#LIST
'''myList=['Rohit',2.4,5,'Pandey']
print(myList)
print(myList.append('v'))
print(myList)
myList.extend([24,25])
print(myList)
myList.insert(2,10)
print(myList)
myList.pop()
print(myList)
'''
#DICTIONARY
myDict={1:'one',2:'Two',3:'Three'}
'''print(myDict.items())
print(myDict.get(3))
myDict.update({4:'Four'})
print(myDict)
print(myDict.values())
print(myDict)
myDict.pop(4)
print(myDict)
'''

#SET
'''mySet={1,2,3,3}
print(mySet)
mySet1={1,'b','c'}
print(mySet | mySet1)
print(mySet & mySet1)
print(mySet-mySet1)
print(mySet1-mySet)
'''
#Boolean