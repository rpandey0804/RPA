# IF ELSE
'''gropu = ['rohit', 'kumar', 'pandey']
if 'rohit' in gropu:
    print('rohit in group')
else:
    print("rohit not in group")
'''
'''x = int(input( "Enter an Integer Numbar :" ))
if not x%2 == 0:
    print("{0} is odd Number".format(x))
else:
    print('{0} is an even Number'.format(x))
'''
'''x = int(input( "Enter an Integer Numbar :" ))
b=100 if x<50 else 200
c=300 if x<5 else 400
print(x,b,c)
'''
'''surname = True
name = 'Rohit' + ('Pandey' if surname else '')
print(name)
'''
platform="Linux"
software="python"
version=2.7
if platform == "Linux":
    if software == "python":
        if version == 2.7:
            print('python 2.7 on linux')
        else:
            print("python on linux")

else:
     print("Not linux platform")