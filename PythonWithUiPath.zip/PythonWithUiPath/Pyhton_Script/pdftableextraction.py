import sys
import os

# === Import Libraries with Exception Handling ===
try:
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    import pytesseract
    from PIL import Image
    import pdfplumber
    import pandas as pd
    import openpyxl
except ImportError as e:
    print(f"Library import error: {e}")
    raise
except Exception as e:
    print(f"Unexpected error during import: {e}")
    raise

# === FUNCTION TO EXTRACT TABLES FROM SPECIFIC PDF PAGE ===
def extract_tables_from_pdf(pdf_path,page_number,output_excel):

    try:
        if not os.path.exists(pdf_path):
            return f"File not found: {pdf_path}"

        if page_number < 1:
            return "Page number must be 1 or greater."

        with pdfplumber.open(pdf_path) as pdf:
            if page_number > len(pdf.pages):
                return f"The PDF has only {len(pdf.pages)} pages."

            page = pdf.pages[page_number - 1]
            tables = page.extract_tables()

            if not tables:
                return f"No tables found on page {page_number}."

            with pd.ExcelWriter(output_excel, engine='openpyxl') as writer:
                for i, table in enumerate(tables, start=1):
                    df = pd.DataFrame(table)
                    df.to_excel(writer, sheet_name=f"Table_{i}", index=False, header=False)

        return f"Extracted {len(tables)} table(s) from page {page_number} to {output_excel}"

    except Exception as e:
        return f"Error: {str(e)}"
    