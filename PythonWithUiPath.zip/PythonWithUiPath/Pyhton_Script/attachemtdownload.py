import sys
import os

# === Import Libraries with Exception Handling ===
try:
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    import pytesseract
    from email import policy
    from email.parser import BytesParser

except ImportError as e:
    print(f"Library import error: {e}")
    raise
except Exception as e:
    print(f"Unexpected error during import: {e}")
    raise


def extract_attachments(eml_file_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    with open(eml_file_path, 'rb') as f:
        msg = BytesParser(policy=policy.default).parse(f)

    def recurse_extract(msg_part, save_dir):
        count = 0
        if msg_part.is_multipart():
            for part in msg_part.iter_parts():
                count += recurse_extract(part, save_dir)
        else:
            if msg_part.get_content_disposition() == 'attachment':
                filename = msg_part.get_filename()
                if filename:
                    filepath = os.path.join(save_dir, filename)
                    with open(filepath, 'wb') as f:
                        f.write(msg_part.get_payload(decode=True))
                    count += 1
        return count

    return recurse_extract(msg, output_dir)
