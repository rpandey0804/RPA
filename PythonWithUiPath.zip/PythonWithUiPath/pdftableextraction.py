import pdfplumber
import pandas as pd

# === INPUT VARIABLES ===
pdf_path = r"C:\Users\rohit\Downloads\Validation Master Plan for Computerized Systems.pdf"
output_excel = "Extracted_Page_Table.xlsx"
page_number = 10  # ✅ Set your desired page number (1-based)

# Validate that page number is at least 1
if page_number < 1:
    raise ValueError("Page number must be 1 or greater.")

# === PROCESS PDF ===
with pdfplumber.open(pdf_path) as pdf:
    if page_number > len(pdf.pages):
        raise ValueError(f"The PDF has only {len(pdf.pages)} pages.")

    page = pdf.pages[page_number - 1]  # 0-based index
    tables = page.extract_tables()

    if not tables:
        print(f"⚠️ No tables found on page {page_number}.")
    else:
        # Save each table to Excel (one sheet per table)
        with pd.ExcelWriter(output_excel, engine='openpyxl') as writer:
            for i, table in enumerate(tables, start=1):
                df = pd.DataFrame(table)
                df.to_excel(writer, sheet_name=f"Table_{i}", index=False, header=False)
        print(f"✅ Extracted {len(tables)} table(s) from page {page_number} → {output_excel}")
