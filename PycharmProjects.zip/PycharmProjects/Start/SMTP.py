import smtplib


def mail(password):
    s = smtplib.SMTP("smtp.gmail.com", 587)
    s.starttls()
    '''password = str(input("Enter your password :"))'''
    s.login('rohitpandey0493@gmail.com', password)
    message = "Hi this message is send by python code"
    s.sendmail('rohitpandey0493@gmail.com', 'snigdhakindo14@gmail.com', message)
    s.quit()
    mes = "success"
    return mes
