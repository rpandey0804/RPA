# Working on Multiple Operatros
from _ast import And

num1=10
num2=20
'''
print("Num1 + Num2= ",num1+num2)
print("Num1 - Num2= ",num1-num2)
print("Num1 * Num2= ",num1*num2)
print("Num1 / Num2= ",num1/num2)
'''
# Assignment Operator
'''num3 = num2 + num1
print(num3)
'''
#Comparison Operator
'''print(num1 > num2)
print(num1 < num2)
print(num1 == num2)
print(num1 != num2)
'''
#Logical Operator
'''x=True
y=False
print("X AND Y",x and y)
print("X OR Y",x or y)
print("NOT Y",not y)
'''
#Bitwise Operator
'''print("Num1 OR Num2",num1|num2)
print("Num1 AND Num2",num1 & num2)
'''
#Membership Operator
x=[1,2,3,4,5]
print(3 in  x)
print(6 in x)