

num=int(input("Enter your number :"))

if num >0:
    print(num,"Number is positive")
elif num==0:
    print(num,"Number is 0")
else:
    print(num,"Number is negative")