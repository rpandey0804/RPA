num=int(input("Enter Your interger number :"))

if num >1:
    for i in range(2,num):
        if num % i==0:
            print(num,"Number is not prime")
            print(i, "times", num // i, "is", num)
            break
    else:
            print("Number is prime")

else:
    print("Number is not prime")
