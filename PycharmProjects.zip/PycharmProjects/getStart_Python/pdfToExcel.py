import tabula

from tabula import convert_into

convert_into("ast_sci_data_tables_sample.pdf", "test_s.csv", output_format="csv")