# IF ELSE IF ELSE
'''marks=int(input("Enter your Marks ="))
if(marks >80):
    print("Grade A")
elif(marks>60)and (marks<=80):
    print("Grade B")
elif(marks>40) and (marks<=60):
    print("Grade C")
else:
    print("Grade D")
'''
# WHILE
'''num = int(input("Enter the value of n= "))
sum=0
if (num < 0):
    print("Enter a valid no")
else:
    while (num > 0):
        sum += num
        num -= 1
        print(sum)
'''
# For Loop
'''for x in range(2,20):
    for y in range(2,x):
        if x % y ==0:
            print(x)
            break
        else:
            print(x)
'''
for n in range( 2, 10 ):
    for x in range( 2, n ):
        if n % x == 0:
            print( n, 'equals', x, '*', n )
        break
    else:
        # loop fell through without finding a facto
        print( n, 'is a prime number' )
