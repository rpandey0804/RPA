
'''def decToBin(n):
    if n>1:
        decToBin(n//2)
        #decNo=decNo.append(n%2)
        print n%2,


dec=input("Enter your no :")

decToBin(dec)
'''


'''def decimalToBinary(n):
    if n > 1:
        decimalToBinary(n // 2)
    print n % 2,

dec=input("Enter your decimal no :")
decimalToBinary(dec)
'''
#binTODec
def binToDec(binNum):
    decNum=0
    power=0
    while binNum >0:
        decNum += 2 ** power *(binNum %10)
        binNum //=10
        power +=1
    return decNum
def decToBin(decNo):
    binNo=0
    power=0
    while decNo >0:
        binNo +=10 ** power *(decNo%2)
        decNo //=2
        power +=1
    return binNo

n=input("Enter your Binary no:-")
x=input("Enter your Binary no:-")
print(str(binToDec(n)))
print(str(decToBin(x)))

