
def findHcf(x,y):

    if x>y:
        smaller=y
    else:
        smaller=x

    for i in range(1,smaller+1):
        if (x%i==0) and (y%i==0):
            hcf=i

    return hcf
num1=54
num2=56

print("The H.C.F. of", num1,"and", num2,"is", findHcf(num1, num2))
