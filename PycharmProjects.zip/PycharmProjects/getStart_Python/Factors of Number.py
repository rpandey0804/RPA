def print_factor(n):
    print("The factor of ",n,"is...")
    for i in range(1,n+1):
        if n%i==0:
            print(i)

num=input("Enter your no: ")
print(print_factor(num))